# frozen_string_literal: true

describe NeedsMinimalPopulationException do
end
