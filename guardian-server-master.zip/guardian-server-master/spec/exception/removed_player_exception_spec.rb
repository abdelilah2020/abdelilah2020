# frozen_string_literal: true

describe RemovedPlayerException do
end
