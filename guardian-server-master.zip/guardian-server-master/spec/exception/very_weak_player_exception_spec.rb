# frozen_string_literal: true

describe VeryWeakPlayerException do
end
