# frozen_string_literal: true

describe InvitedPlayerException do
end
