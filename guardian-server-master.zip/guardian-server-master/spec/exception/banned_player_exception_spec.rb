# frozen_string_literal: true

describe BannedPlayerException do
end
