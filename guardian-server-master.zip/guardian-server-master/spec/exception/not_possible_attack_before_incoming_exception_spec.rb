# frozen_string_literal: true

describe NotPossibleAttackBeforeIncomingException do
end
