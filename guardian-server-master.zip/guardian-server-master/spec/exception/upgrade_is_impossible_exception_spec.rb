# frozen_string_literal: true

describe UpgradeIsImpossibleException do
end
