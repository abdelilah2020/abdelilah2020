# frozen_string_literal: true

describe Client::Base do
end
