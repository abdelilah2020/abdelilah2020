# frozen_string_literal: true

describe Client::Mobile do
  it 'test mobile client' do
    client = Client::Mobile.new
    client.login
    client.get('/game.php?screen=main')
    client.post('/game.php?screen=main')
  end
end
