# frozen_string_literal: true
# # frozen_string_literal: true

# describe Client::Logged do
#   it 'logged client with desktop' do
#     client = Client::Logged.desktop
#     client.get('/game.php')
#     client.post('/game.php')
#   end

#   it 'logged client with mobile' do
#     client = Client::Logged.mobile
#     client.get('/game.php')
#     client.post('/game.php')
#   end
# end
