# frozen_string_literal: true

describe ApplicationController do
end
