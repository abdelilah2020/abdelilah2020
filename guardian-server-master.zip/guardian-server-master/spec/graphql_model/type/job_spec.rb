# frozen_string_literal: true

describe Type::Job do
end
