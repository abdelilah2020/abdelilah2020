# frozen_string_literal: true

describe Type::Hash do
end
