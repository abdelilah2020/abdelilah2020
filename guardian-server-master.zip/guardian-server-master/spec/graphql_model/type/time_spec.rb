# frozen_string_literal: true

describe Type::Time do
end
