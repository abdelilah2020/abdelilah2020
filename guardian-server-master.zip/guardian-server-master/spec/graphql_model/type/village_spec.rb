# frozen_string_literal: true

describe Type::Village do
end
