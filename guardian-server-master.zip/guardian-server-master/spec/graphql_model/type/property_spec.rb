# frozen_string_literal: true

describe Type::Property do
end
