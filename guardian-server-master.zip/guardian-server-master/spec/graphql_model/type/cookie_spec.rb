# frozen_string_literal: true

describe Type::Cookie do
end
