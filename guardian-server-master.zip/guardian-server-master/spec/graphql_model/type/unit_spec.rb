# frozen_string_literal: true

describe Type::Unit do
end
