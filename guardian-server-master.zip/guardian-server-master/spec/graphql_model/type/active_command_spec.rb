# frozen_string_literal: true

describe Type::ActiveCommand do
end
