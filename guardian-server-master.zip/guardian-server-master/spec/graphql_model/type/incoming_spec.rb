# frozen_string_literal: true

describe Type::Incoming do
end
