# frozen_string_literal: true

describe Type::Player do
end
