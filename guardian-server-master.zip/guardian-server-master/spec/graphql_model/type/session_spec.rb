# frozen_string_literal: true

describe Type::Session do
end
