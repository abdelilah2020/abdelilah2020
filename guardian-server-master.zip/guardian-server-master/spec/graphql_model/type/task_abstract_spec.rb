# frozen_string_literal: true

describe Type::TaskAbstract do
end
