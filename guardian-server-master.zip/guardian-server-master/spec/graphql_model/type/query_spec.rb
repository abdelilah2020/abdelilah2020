# frozen_string_literal: true

describe Type::Query do
end
