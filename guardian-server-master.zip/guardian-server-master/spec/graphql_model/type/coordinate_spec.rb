# frozen_string_literal: true

describe Type::Coordinate do
end
