# frozen_string_literal: true

describe Type::Base do
end
