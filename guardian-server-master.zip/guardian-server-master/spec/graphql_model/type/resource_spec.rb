# frozen_string_literal: true

describe Type::Resource do
end
