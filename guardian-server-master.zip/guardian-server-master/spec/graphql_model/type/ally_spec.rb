# frozen_string_literal: true

describe Type::Ally do
end
