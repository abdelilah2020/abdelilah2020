# frozen_string_literal: true

describe Type::TroopModel do
end
