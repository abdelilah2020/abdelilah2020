# frozen_string_literal: true

describe Type::Report do
end
