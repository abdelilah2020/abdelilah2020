# frozen_string_literal: true

describe Type::VillageModel do
end
