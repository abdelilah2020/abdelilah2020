# frozen_string_literal: true

describe Type::Troop do
end
