# frozen_string_literal: true

describe Mutation::Root do
end
