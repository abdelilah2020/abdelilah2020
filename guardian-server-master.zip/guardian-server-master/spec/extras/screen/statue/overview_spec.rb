# frozen_string_literal: true

describe Screen::Statue::Overview do
  it 'parse statue overview' do
    Screen::Statue::Overview.new
  end
end
