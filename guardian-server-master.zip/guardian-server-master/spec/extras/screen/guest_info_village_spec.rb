# frozen_string_literal: true

describe Screen::GuestInfoVillage do
end
