# frozen_string_literal: true

describe Screen::ReportList do
  it 'test load report screen' do
    report_screen = Screen::ReportList.new(mode: 'attack')
  end
end
