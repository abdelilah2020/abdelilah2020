# frozen_string_literal: true

describe Screen::ReportView do
  # it 'check barbarian report moral' do
  #   report = Screen::ReportView.new(view: 59007337).report
  #   # expect(report.target_id).to eq(nil)
  #   binding.pry
  #   expect(report.moral).to eq(100)
  # end
  
end
