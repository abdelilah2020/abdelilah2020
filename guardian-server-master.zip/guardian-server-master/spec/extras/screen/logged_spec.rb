# frozen_string_literal: true

describe Screen::Logged do
end
