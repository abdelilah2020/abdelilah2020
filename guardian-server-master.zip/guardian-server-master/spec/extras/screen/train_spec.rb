# frozen_string_literal: true

describe Screen::Train do
  it 'load_screen' do
    report_screen = Screen::Train.new
  end
end
