# frozen_string_literal: true

describe Screen::Base do
end
