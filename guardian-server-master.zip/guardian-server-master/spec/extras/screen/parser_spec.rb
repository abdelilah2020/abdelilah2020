# frozen_string_literal: true

describe Screen::Parser do
end
