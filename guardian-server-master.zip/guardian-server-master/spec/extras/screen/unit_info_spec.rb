# frozen_string_literal: true

describe Screen::UnitInfo do
end
