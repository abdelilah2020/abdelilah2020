# frozen_string_literal: true

describe Screen::Guest do
end
