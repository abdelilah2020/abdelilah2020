# frozen_string_literal: true

describe Screen::Simulator do
end
