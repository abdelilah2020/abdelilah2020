# frozen_string_literal: true

describe Event::FirstLogin do
end
