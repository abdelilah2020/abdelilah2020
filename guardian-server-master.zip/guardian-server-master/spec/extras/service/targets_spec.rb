# frozen_string_literal: true

# # frozen_string_literal: true

# describe Service::Targets do
#   include Service::Targets

#   it 'update_steal_candidates' do
#     update_steal_candidates
#   end

#   it 'sort_by_priority' do
#     @distance = 10
#     sort_by_priority([
#       Village.new(x: 5, y: 5),
#       Village.new(x: 15, y: 15),
#       Village.new(x: 5, y: 15),
#       Village.new(x: 15, y: 5)
#     ])
#   end
# end
