# frozen_string_literal: true

describe Village do
end
