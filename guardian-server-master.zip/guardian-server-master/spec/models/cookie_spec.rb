# frozen_string_literal: true

describe Cookie do
end
