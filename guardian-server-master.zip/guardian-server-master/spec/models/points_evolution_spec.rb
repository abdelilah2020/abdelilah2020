# frozen_string_literal: true

describe PointsEvolution do
end
