# frozen_string_literal: true

describe Unit do
end
