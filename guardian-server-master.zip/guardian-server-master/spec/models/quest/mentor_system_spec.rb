# frozen_string_literal: true

# # frozen_string_literal: true

# describe Quest::MentorSystem do
#   it 'just start' do
#     Quest::MentorSystem.new.start
#   end
# end
