# frozen_string_literal: true
# # frozen_string_literal: true

# describe Quest::Abstract do
# end
