# frozen_string_literal: true

describe Resource do
end
