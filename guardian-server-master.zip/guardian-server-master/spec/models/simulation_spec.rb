# frozen_string_literal: true

describe Simulation do
end
