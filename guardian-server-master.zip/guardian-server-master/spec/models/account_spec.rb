# frozen_string_literal: true

describe Account do
end
