# frozen_string_literal: true

describe Task::Abstract do
end
