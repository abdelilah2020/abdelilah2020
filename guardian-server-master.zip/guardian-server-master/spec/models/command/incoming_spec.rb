# frozen_string_literal: true

describe Command::Incoming do
end
