# frozen_string_literal: true

describe Command::Abstract do
end
