# frozen_string_literal: true

describe Command::My do
end
