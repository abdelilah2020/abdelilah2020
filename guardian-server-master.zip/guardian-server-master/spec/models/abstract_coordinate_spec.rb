# frozen_string_literal: true

describe AbstractCoordinate do
end
