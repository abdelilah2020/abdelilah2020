# frozen_string_literal: true

describe Building do
end
