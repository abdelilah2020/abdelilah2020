# frozen_string_literal: true

describe Player do
end
