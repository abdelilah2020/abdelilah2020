# frozen_string_literal: true

class UpgradeIsImpossibleException < RuntimeError
end
