# frozen_string_literal: true

class RemovedPlayerException < RuntimeError
end
