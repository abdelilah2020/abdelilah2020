# frozen_string_literal: true

class BannedPlayerException < RuntimeError
end
