# frozen_string_literal: true

class VeryWeakPlayerException < RuntimeError
end
