# frozen_string_literal: true
# # frozen_string_literal: true

# class Quest::BuildWood < Quest::Abstract
# end
