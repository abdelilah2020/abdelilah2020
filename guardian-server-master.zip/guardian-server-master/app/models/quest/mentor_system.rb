# frozen_string_literal: true
# # frozen_string_literal: true

# class Quest::MentorSystem < Quest::Abstract
#   def start
#     Client::Logged.mobile.get('/game.php?screen=mentor')
#   end
# end
