# frozen_string_literal: true

module Type::Coordinate
  include Type::Base
end
