# frozen_string_literal: true

module Type::Cookie
  include Type::Base
end
