# frozen_string_literal: true

module Type::PointsEvolution
  include Type::Base
end
