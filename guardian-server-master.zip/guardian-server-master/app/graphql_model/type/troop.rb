# frozen_string_literal: true

module Type::Troop
  include Type::Base
end
