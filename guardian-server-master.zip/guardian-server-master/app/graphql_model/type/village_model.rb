# frozen_string_literal: true

module Type::VillageModel
  include Type::Base
end
