# frozen_string_literal: true

module Type::Building
  include Type::Base
  definition_name 'MetaBuilding'
end
