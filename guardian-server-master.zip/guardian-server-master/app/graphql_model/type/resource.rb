# frozen_string_literal: true

module Type::Resource
  include Type::Base
end
