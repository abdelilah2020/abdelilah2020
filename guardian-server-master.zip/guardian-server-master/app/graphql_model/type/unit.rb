# frozen_string_literal: true

module Type::Unit
  include Type::Base
end
