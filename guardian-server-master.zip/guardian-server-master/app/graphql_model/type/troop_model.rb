# frozen_string_literal: true

module Type::TroopModel
  include Type::Base
end
