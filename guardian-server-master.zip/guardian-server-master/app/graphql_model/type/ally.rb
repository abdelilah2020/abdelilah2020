# frozen_string_literal: true

module Type::Ally
  include Type::Base
end
