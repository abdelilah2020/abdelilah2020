# frozen_string_literal: true
# Webdrivers::Chromedriver.required_version = '74.0.3729.6'
# Webdrivers.install_dir = "#{Rails.root}/tmp/webdrivers"
# Webdrivers::Chromedriver.update
