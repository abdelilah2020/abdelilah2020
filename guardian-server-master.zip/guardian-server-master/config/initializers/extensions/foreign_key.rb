# frozen_string_literal: true

class Mongoid::Fields::ForeignKey
  def list?
    false
  end
end
