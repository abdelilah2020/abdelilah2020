# frozen_string_literal: true

class Mongoid::Fields::Standard
  def polymorphic?
    false
  end
end
